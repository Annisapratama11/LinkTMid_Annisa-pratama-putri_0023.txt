/*NIM		:13020210023
NAMA		:ANNISA PRATAMA PUTRI*/


import java.util.Scanner;

public class TesterErr0023 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in) {
		int i = input.nextInt();
		int k = 100;
		char c = 's';
		boolean falses = true;
		int j = i+1;
		System.out.println("j adalah "+ j + " k adalah "+k + " dan c adalah "+c + " dan true adalah "+falses); 
	}
}