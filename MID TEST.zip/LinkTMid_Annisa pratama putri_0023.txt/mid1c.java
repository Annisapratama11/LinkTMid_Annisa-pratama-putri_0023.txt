/*NIM		:13020210023
NAMA		:ANNISA PRATAMA PUTRI*/

interface A {
    public void aaa();
}

interface B extends A {
    // tidak perlu mendefinisikan ulang metode aaa()
}

class Central0023 implements B {
    public void aaa() {
        System.out.println("aaa");
    }

    public static void main(String arg[]) {
        Central0023 obj = new Central0023();
        System.out.println("main");
        obj.aaa();
    }
}
