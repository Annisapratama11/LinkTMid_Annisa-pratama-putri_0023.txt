/*NIM		:13020210023
NAMA		:ANNISA PRATAMA PUTRI*/

import java.util.Scanner;

public class Kelas0023 {
    public static void main(String[] args) {
        double mil, meter;
        final double KONVERSI = 1.609; 

        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan jarak dalam mil: ");
        mil = input.nextDouble();

        meter = mil * KONVERSI * 1000; 

        System.out.printf("%.3f mil = %.3f meter", mil, meter);
    }
}
